/**
 * Copyright (c) MyScript
 */
package com.myscript.atk.itc.sample;

public class Debug
{
  // Widget debug information
  public static final boolean DBG = false;

  // Draw debug information
  public static final boolean DBG_DRAW = false;
}
